

<?php 

session_start();
	include "config.php";
	include"enc.php";
	$key ="!@#123!@#";
	$crypt = new Encryption($key);
	$txt=$crypt->encrypt($_POST["txt"]);
	$sql="Select data_owner_tab.EMAIL, data_owner_tab.DNAME, upload_file.FNAME,
  upload_file.FATT, upload_file.FILE, upload_file.FID
From upload_file Inner Join
  data_owner_tab On upload_file.DID = data_owner_tab.DID";
	$res=$con->query($sql);
	if($res->num_rows>0)
	{
		?>
			<table class='table table-bordered'>
				
				<tr>
					<th>S.No</th>
					<th>File Name</th>
					<th>Owner Name</th>
					<th>Email Id</th>
					<th>Request</th>
				</tr>
		<?php
		$i=0;
		while($row=$res->fetch_assoc())
		{
			if(strpos($crypt->decrypt($row["FILE"]),$_POST["txt"])!==false||strpos($crypt->decrypt($row["FATT"]),$_POST["txt"])!==false||strpos($crypt->decrypt($row["FNAME"]),$_POST["txt"])!==false)
			{$i++;
			?>
				<tr>
					<td><?php echo $i;?></td>
					<td><?php echo $crypt->decrypt($row["FILE"])?></td>
					<td><?php echo $row["DNAME"];?></td>
					<td><?php echo $row["EMAIL"];?></td>
					<td><input type='button' vlu='<?php echo $row["FID"]; ?>' class='btn btn-success btn-sm but'value='Request To Secret Key'></td>
				</tr>
			<?php
			}
		}
	}

?>
<script>
	$(document).ready(function(){
		$(".but").click(function(){
			var fid=$(this).attr("vlu");
			var uid="<?php echo $_SESSION["UID"]; ?>";
			$.post("send_request.php",{fid:fid,uid:uid},function(data){
				alert(data);
			});
		});
	});
</script>