	<html>
		<?php 
		
		session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
		
		if(isset($_SESSION["CID"]))
		{
		}
		else{
			header("location:index.php");
		}
		?>
		<?php include "config.php";
			include "head.php"; 
		?>
		<body>
			<?php include "top_nav.php"; ?>
			<div class="container" style="margin-top:40px;">
			<div class="row">
					<div class="col-md-3">
						<?php include "ca_side_nav.php"; ?>
					</div>
				
					<div class="col-md-9">
						<h2><i class='fa fa-users'></i> View Attackers</h2><hr><br>
						<?php
							$sql="Select attackers.LOGS, upload_file.FILE, user_tab.EMAIL As UMAIL,
  data_owner_tab.EMAIL As DMAIL
From attackers Inner Join
  user_tab On attackers.UID = user_tab.UID Inner Join
  upload_file On attackers.SKEY = upload_file.FKEY Inner Join
  data_owner_tab On upload_file.DID = data_owner_tab.DID";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								?>
									<table class='table table-bordered'>
										<tr>
											<th>S.No</th>
											<th>User</th>
											<th>File</th>
											<th>Owner</th>
											<th>Download Date and Time</th>
										</tr>
								<?php
								$i=0;
								while($row=$res->fetch_assoc())
								{$i++;
								?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $row["UMAIL"]; ?></td>
										<td><?php echo $crypt->decrypt($row["FILE"]); ?></td>
										<td><?php echo $row["DMAIL"]; ?></td>
										<td><?php echo $row["LOGS"]; ?></td>
									</tr>
								<?php
									
								}
							}
						?>
					</table>
					</div>		
			</div>
			<?php include "footer.php"; ?>
		</body>
		<script>
			$(document).ready(function(){
				$(".dates").datepicker({
					dateFormat:"yy-mm-dd"
				});
			});
		</script>
	</html>