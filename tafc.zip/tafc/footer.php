<footer>
	<p class='text-center'></p>
</footer>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
	$(document).ready(function(){
		$(".alert").hide(3000);
	});
</script>
