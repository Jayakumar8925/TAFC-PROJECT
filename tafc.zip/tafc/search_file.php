<html>
	<?php 
	
	session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
	if(isset($_SESSION["UID"]))
	{
	}
	else{
		header("location:index.php");
	}
	?>
	<?php include "config.php";
		include "head.php"; 
	?>
	<body style="background-image:url(pic/10.jpg); background-size:cover; color:white;">
		<?php include "top_nav.php"; ?>
		<div class="container" style="margin-top:40px;">
		<div class="row">
				<div class="col-md-3">
					<?php include "user_side_nav.php"; ?>
				</div>
				<div class="col-md-9" >
					
					<h2><i class='fa fa-search'></i> Search File</h2><hr>
					<div class='col-md-offset-3 col-md-5'>
					<br>
					<div class='form-group'>	
							<label style="color:yellow; font-size:20px;">File Name or Attributes</label>
							<input type='text' class='form-control' id='stxt'>							
						</div>
						<input  type='button' class='btn btn-success btn-sm pull-right' value='Search' id='bt'>
					<br><br>
					
					</div>
				</div>	
				
				<div class="col-md-9" id='out'>	
				
				</div>				
				</div>		
		</div>
		<?php include "footer.php"; ?>
	</body>
	<script>
		$(document).ready(function(){
			$("#bt").click(function(){
				var txt=$("#stxt").val();
				if(txt!="")
				{
					$.post("search.php",{txt:txt},function(data){
						$("#out").html(data);
					});
				}
			});
		});
	</script>
</html>
