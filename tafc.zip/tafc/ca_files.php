	<html>
		<?php 
		
		session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
		
		if(isset($_SESSION["CID"]))
		{
		}
		else{
			header("location:index.php");
		}
		?>
		<?php include "config.php";
			include "head.php"; 
		?>
		<body style="background-image:url(pic/04.jpg); color:white; background-size:cover;">
			<?php include "top_nav.php"; ?>
			<div class="container" style="margin-top:40px;">
			<div class="row">
					<div class="col-md-3">
						<?php include "ca_side_nav.php"; ?>
					</div>
				
					<div class="col-md-9">
						<h2><i class='fa fa-file'></i> Files</h2><hr>
				<br>

					<?php
						$sql="select * from upload_file";
						$res=$con->query($sql);
						if($res->num_rows>0)
						{
						?>
							<table class='table table-bordered'>
								<tr>
									<th>S.No</th>
									<th>File</th>
									<th>File Name</th>
									<th>Attribute</th>
									<th>Key</th>
									<th>Open Date</th>
									<th>End Date</th>
									<th>Upload Date</th>
									
								
								</tr>
						<?php
							$i=0;
							while($row=$res->fetch_assoc())
							{$i++;
								?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $crypt->decrypt($row["FILE"]);?></td>
										<td><?php echo$crypt->decrypt($row["FNAME"]); ?></td>
										<td><?php echo $crypt->decrypt($row["FATT"]);?></td>
										<td><?php echo $row["FKEY"];?></td>
										<td><?php echo $row["ODATE"];?></td>
										<td><?php echo $row["CDATE"]?></td>
										<td><?php echo $row["UDATE"]?></td>
										
										
									</tr>
								<?php								
							}
						}
					?>
					</table>
				</div>		
			</div>
			<?php include "footer.php"; ?>
		</body>
		<script>
			$(document).ready(function(){
				$(".dates").datepicker({
					dateFormat:"yy-mm-dd"
				});
			});
		</script>
	</html>