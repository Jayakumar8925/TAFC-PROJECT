<html>
	<?php include "head.php"; 
	session_start();
	?>
	<?php include "config.php"; ?>
	<body>
	<body style="background-image:url(pic/03.jpg); background-size:cover;">
		<?php include "top_nav.php"; ?>
		<div class="row">
				<div class="col-md-offset-1 col-md-3 " style='margin-top:80px; '>
					<h2 class="head"style="color:yellow;">CA- Central Authority</h2>
					<?php 
						if(isset($_POST["submit"]))
						{
							$sql="select * from ca_tab where CNAME='{$_POST["cname"]}' and CPASS='{$_POST["cpass"]}'";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								$row=$res->fetch_assoc();
								header("location:cahome.php");
								$_SESSION["CID"]=$row["CID"];
								$_SESSION["CNAME"]=$row["CNAME"];
								
							}
							else
							{
								echo "<div class='alert alert-danger'>Username and Password Mismatch</div>";
							}
						}
					?>
					<hr>
						<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
			    	  	<div class="form-group">
							 <label for="user_name" style="color:white">User Name</label>
			    		    <input class="form-control" name="cname"  id="user" type="text" required>
			    		</div>
			    		<div class="form-group">
							<label for="pass" style="color:white">Password</label>
			    			<input class="form-control" id="cpass" name="cpass" type="password" value="" required>
			    		</div>	
			    		<button class="btn btn-primary pull-right" name="submit" type="submit"><i class="fa fa-sign-in"></i> Login Here</button>
			      	</form>
				</div>
		</div>	
		
	</body>
	<?php include "footer.php"; ?>
</html>