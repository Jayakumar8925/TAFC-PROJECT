	<html>
		<?php 
		
		session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
		
		if(isset($_SESSION["CID"]))
		{
		}
		else{
			header("location:index.php");
		}
		?>
		<?php include "config.php";
			include "head.php"; 
		?>
		<body style="background-image:url(pic/key1.jpg); color:white; background-size:cover;">
			<?php include "top_nav.php"; ?>
			<div class="container" style="margin-top:40px;">
			<div class="row">
					<div class="col-md-3">
						<?php include "ca_side_nav.php"; ?>
					</div>
						<h2><i class='fa fa-key'></i> SK Requests</h2><hr><br>
						<?php
							$sql="Select request_tab.*,user_tab.*, user_tab.EMAIL As UMAIL, request_tab.STATUS,
  data_owner_tab.EMAIL As DMAIL, data_owner_tab.*,	upload_file.*
From request_tab Inner Join
  upload_file On request_tab.FID = upload_file.FID Inner Join
  data_owner_tab On upload_file.DID = data_owner_tab.DID Inner Join
  user_tab On request_tab.UID = user_tab.UID
Where request_tab.STATUS = 0 and request_tab.RID={$_GET["rid"]} ";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								$row=$res->fetch_assoc();
								?>
								<div class="col-md-3">
									<table class='table table-bordered'>
										<tr>
											<th colspan="2"><center>User Details</center></th>
										</tr>
										<tr>
											<td>User Name</td>
											<td><?php echo $row["UNAME"];?></td>
										</tr>
										<tr>
											<td>Email</td>
											<td><?php echo $row["UMAIL"];?></td>
										</tr>
										<tr>
											<td>Contact</td>
											<td><?php echo $row["CONTACT"];?></td>
										</tr>
									</table>
									</div>	
									<div class="col-md-3">
									<table class='table table-bordered'>
										<tr>
											<th colspan="2"><center>Owner Details</center></th>
										</tr>
										<tr>
											<td>User Name</td>
											<td><?php echo $row["DNAME"];?></td>
										</tr>
										<tr>
											<td>Email</td>
											<td><?php echo $row["DMAIL"];?></td>
										</tr>
										<tr>
											<td>Contact</td>
											<td><?php echo $row["DCON"];?></td>
										</tr>
									</table>
									</div>	
									<div class="col-md-3"><!---->
									<table class='table table-bordered'>
										<tr>
											<th colspan="2"><center>File Details</center></th>
										</tr>
										<tr>
											<td>File Name</td>
											<td><?php echo $crypt->decrypt($row["FILE"]);?></td>
										</tr>
										<tr>
											<td>Open</td>
											<td><?php echo  $row["ODATE"];?></td>
										</tr>
										<tr>
											<td>Close</td>
											<td><?php echo $row["CDATE"];?></td>
										</tr>
										<tr>
											<td>Update</td>
											<td><?php echo $row["UDATE"];?></td>
										</tr>
										<tr>
											<td>Keyword</td>
											<td><?php echo $row["FKEY"];?></td>
										</tr>
									</table>
									</div>
									<div class="col-md-offset-6 col-md-4 form-group">
									<input type='hidden' id='uid' value='<?php echo $row["UID"];?>'>
									<input type='hidden' id='fid' value='<?php echo $row["FID"];?>'>
									<input type='hidden' id='rid' value='<?php echo $row["RID"];?>'>
										<label style="color:yellow;">Keyword</label>
										<input type="text" id="ky" class='form-control' placeholder="Keyword"><br>
										<input type="button" class='btn btn-success pull-right btn-sm' id="but" value='Send'>
									</div>
								<?php									
								}
							
						?>
							
			</div>
			<?php include "footer.php"; ?>
		</body>
		<script>
			$(document).ready(function(){
				$("#but").click(function(){
					var ky=$("#ky").val();
					var fid=$("#fid").val();
					var uid=$("#uid").val();
					var rid=$("#rid").val();
					
					if(ky!="")
					{
						$.post("send.php",{uid:uid,fid:fid,ky:ky,rid:rid},function(data){
							alert("Keyword Send Successfully");
							
							window.open("view_sk.php","_self");
						})
					}
				});
			});
		</script>
	</html>