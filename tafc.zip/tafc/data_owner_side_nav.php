<style>
	.sid ul{	
		background:#c1c1c1;
	}
	.sid ul li{
	
	}
	.sid ul li a{

		color:white!important;
		font-size:18px;
		font-family:vijaya;
	
	}
	.sid ul li a:hover
	{
		color:black!important;
	}
	hr{
		padding:0px!important;
		margin:0px!important;
	}
</style>
<div class="sid">
<ul class="nav nav-pills nav-stacked" >
	<li><a href="dhome.php"> <i class="fa fa-image"></i> Upload Data</a><hr></li>
	<li><a href="dhome.php"> <i class="fa fa-image"></i> Upload Data</a><hr></li>
	<li><a href="dhome.php"> <i class="fa fa-image"></i> Upload Data</a><hr></li>
	
	<li><a href="logout.php"> <i class="fa fa-image"></i> Logout</a></li>

	
</ul>
</div>