-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2023 at 05:28 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tafc`
--
CREATE DATABASE IF NOT EXISTS `tafc` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tafc`;

-- --------------------------------------------------------

--
-- Table structure for table `attackers`
--

CREATE TABLE IF NOT EXISTS `attackers` (
  `AID` int(11) NOT NULL AUTO_INCREMENT,
  `UID` int(11) NOT NULL,
  `SKEY` varchar(150) NOT NULL,
  `LOGS` datetime NOT NULL,
  PRIMARY KEY (`AID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `attackers`
--

INSERT INTO `attackers` (`AID`, `UID`, `SKEY`, `LOGS`) VALUES
(1, 1, '030753', '2017-10-16 11:04:52'),
(2, 1, '030753', '2017-10-16 11:04:59'),
(3, 1, '030753', '2017-10-16 11:05:37'),
(4, 2, '822950', '2023-03-23 19:21:47'),
(5, 2, '822950', '2023-03-23 19:22:00'),
(6, 2, '029266', '2023-03-23 19:31:12'),
(7, 2, '762716', '2023-03-23 22:41:31'),
(8, 2, '326864', '2023-03-23 22:43:12'),
(9, 2, '326864', '2023-03-23 22:43:27'),
(10, 2, '326864', '2023-03-23 22:43:44'),
(11, 2, '326864', '2023-03-23 22:43:48'),
(12, 2, '326864', '2023-03-23 22:44:50'),
(13, 2, '326864', '2023-03-23 22:45:05'),
(14, 2, '326864', '2023-03-23 22:45:22'),
(15, 2, '326864', '2023-03-23 22:45:25'),
(16, 2, '326864', '2023-03-23 22:45:34'),
(17, 2, '326864', '2023-03-23 22:45:45'),
(18, 2, '326864', '2023-03-23 22:45:51'),
(19, 2, '326864', '2023-03-23 22:47:39'),
(20, 2, '326864', '2023-03-23 22:47:53'),
(21, 2, '326864', '2023-03-23 22:48:08'),
(22, 2, '326864', '2023-03-23 22:49:38'),
(23, 2, '326864', '2023-03-23 22:49:53'),
(24, 2, '326864', '2023-03-23 22:50:08');

-- --------------------------------------------------------

--
-- Table structure for table `ca_tab`
--

CREATE TABLE IF NOT EXISTS `ca_tab` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `CNAME` varchar(150) NOT NULL,
  `CPASS` varchar(150) NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ca_tab`
--

INSERT INTO `ca_tab` (`CID`, `CNAME`, `CPASS`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `cloud_tab`
--

CREATE TABLE IF NOT EXISTS `cloud_tab` (
  `CID` int(11) NOT NULL AUTO_INCREMENT,
  `CNAME` varchar(150) NOT NULL,
  `CPASS` varchar(150) NOT NULL,
  PRIMARY KEY (`CID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cloud_tab`
--

INSERT INTO `cloud_tab` (`CID`, `CNAME`, `CPASS`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `data_owner_tab`
--

CREATE TABLE IF NOT EXISTS `data_owner_tab` (
  `DID` int(11) NOT NULL AUTO_INCREMENT,
  `DNAME` varchar(150) NOT NULL,
  `EMAIL` varchar(150) NOT NULL,
  `PASS` varchar(150) NOT NULL,
  `DCON` varchar(150) NOT NULL,
  PRIMARY KEY (`DID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `data_owner_tab`
--

INSERT INTO `data_owner_tab` (`DID`, `DNAME`, `EMAIL`, `PASS`, `DCON`) VALUES
(1, 'zensmith', 'zen@gmail.com', '123', '9876543210'),
(2, 'violet', 'violet@gmail.com', '123', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `request_tab`
--

CREATE TABLE IF NOT EXISTS `request_tab` (
  `RID` int(11) NOT NULL AUTO_INCREMENT,
  `FID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `LOGS` date NOT NULL,
  `STATUS` int(11) NOT NULL,
  PRIMARY KEY (`RID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `request_tab`
--

INSERT INTO `request_tab` (`RID`, `FID`, `UID`, `LOGS`, `STATUS`) VALUES
(4, 23, 1, '2017-10-14', 1),
(5, 24, 1, '2017-10-16', 1),
(6, 30, 2, '2023-03-23', 1),
(7, 31, 2, '2023-03-23', 0),
(8, 31, 2, '2023-03-23', 1),
(9, 1, 2, '2023-03-23', 1),
(10, 2, 2, '2023-03-23', 1),
(11, 5, 2, '2023-03-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `secret_keys`
--

CREATE TABLE IF NOT EXISTS `secret_keys` (
  `SID` int(11) NOT NULL AUTO_INCREMENT,
  `FID` int(11) NOT NULL,
  `FKEY` varchar(150) NOT NULL,
  `UID` int(11) NOT NULL,
  `LOGS` date NOT NULL,
  PRIMARY KEY (`SID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `secret_keys`
--

INSERT INTO `secret_keys` (`SID`, `FID`, `FKEY`, `UID`, `LOGS`) VALUES
(1, 23, '030753', 1, '2017-10-14'),
(2, 24, '365040', 1, '2017-10-16'),
(3, 30, '822950', 2, '2023-03-23'),
(4, 31, '029266', 2, '2023-03-23'),
(5, 1, '762716', 2, '2023-03-23'),
(6, 2, '326864', 2, '2023-03-23'),
(7, 5, '135821', 2, '2023-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `upload_file`
--

CREATE TABLE IF NOT EXISTS `upload_file` (
  `FID` int(11) NOT NULL AUTO_INCREMENT,
  `DID` int(11) NOT NULL,
  `FNAME` varchar(150) NOT NULL,
  `FATT` varchar(150) NOT NULL,
  `FKEY` varchar(150) NOT NULL,
  `ODATE` date NOT NULL,
  `CDATE` date NOT NULL,
  `OTIME` varchar(150) NOT NULL,
  `CTIME` varchar(150) NOT NULL,
  `UDATE` datetime NOT NULL,
  `FILE` varchar(150) NOT NULL,
  PRIMARY KEY (`FID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `upload_file`
--

INSERT INTO `upload_file` (`FID`, `DID`, `FNAME`, `FATT`, `FKEY`, `ODATE`, `CDATE`, `OTIME`, `CTIME`, `UDATE`, `FILE`) VALUES
(1, 1, 'iELDgPxf3awEkzZb166OQ2IxxJ8M/Vd+zfbXYsXp6Pk=', 'xNvvJSHtD4BU7zBu/VyfCeQYW0UHasiZ5x8b6ghZJwc=', '762716', '2023-03-01', '2023-03-31', '1', '24', '2023-03-23 22:35:52', 'BFGyKJTvptbAb6XAdNhOxMexaO4aGw+7sf4Zq4rZSdATqjJqW2eer4LPydsgVzOS'),
(2, 1, '+NXTslWb43w4qMmKt+jUvzFYfb/nDUwPHVP+MSlK7gQ=', 'FrL01Iqszlz5k5RtdaKipsi0emKJPVhVPbsFMiw22a0=', '326864', '2023-03-01', '2023-03-31', '1', '2', '2023-03-23 22:36:39', 'HrIsg2vxL5Jte9OLwWuo8AdPQEZOzMuuJX1Td8gAdtDTM35VlENZ8zB7dwv0kidp'),
(5, 1, 'OxKKkIwZPQty42OAuRj+ukMH5zQggM0ZoiCFkSS59uc=', 'wL4TBXtCOfsolrk3OnL1fNnUQ7G/jVoWdxKCCFiEwRc=', '135821', '2023-03-01', '2023-03-21', '1', '2', '2023-03-23 22:39:44', 'JX5hddT3JPcHgpLsd1ciReOZifXJb6ErzNcaaru+nZVXQHmjYzlXkNHcm2bIi/Dm');

-- --------------------------------------------------------

--
-- Table structure for table `user_tab`
--

CREATE TABLE IF NOT EXISTS `user_tab` (
  `UID` int(11) NOT NULL AUTO_INCREMENT,
  `UNAME` varchar(150) NOT NULL,
  `EMAIL` varchar(150) NOT NULL,
  `UPASS` varchar(150) NOT NULL,
  `CONTACT` varchar(150) NOT NULL,
  PRIMARY KEY (`UID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_tab`
--

INSERT INTO `user_tab` (`UID`, `UNAME`, `EMAIL`, `UPASS`, `CONTACT`) VALUES
(1, 'Jhon', 'jhon@gmail.com', '123', '9876541230'),
(2, 'soundh', 'soundh@gmail.com', '123', '12345678');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
