<html>
	<?php include "head.php"; 
	session_start();
	?>
	<?php include "config.php"; ?>
	<body>
		<?php include "top_nav.php"; ?>
		<div class="row">
				<div class="col-md-offset-4 col-md-4 well" style='margin-top:80px;'>
					<h2 class='head'>User</h2>
					<h3> Registration</h3>
					<?php 
						if(isset($_POST["submit"]))
						{
							 $sql="insert into user_tab(UNAME,EMAIL,UPASS,CONTACT)values('{$_POST["name"]}','{$_POST["email"]}','{$_POST["pass1"]}','{$_POST["contact"]}')";
							if($con->query($sql))
							{
								echo "<div class='alert alert-success'>Registration Successfully</div>";
								echo"<a href='user.php'><i class='fa fa-arrow-left'></i> Back to Login</a>";
							}
						}
					?>
					<hr>
						<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
			    	  	<div class="form-group">
							 <label for="user_name" class="text-primary">User Name</label>
			    		    <input class="form-control" name="name"  id="name" type="text" placeholder="User Name" required>
			    		</div>
						 <div class="form-group">
							 <label for="user_name" class="text-primary">Email ID</label>
			    		    <input class="form-control" name="email"  id="email" type="email" required placeholder="Email ID">
			    		</div>
						<div class="form-group">
							 <label for="user_name" class="text-primary">Password</label>
			    		    <input class="form-control" name="pass1"  id="pass1" type="password" required placeholder="Password">
			    		</div>
						<div class="form-group">
							 <label for="user_name" class="text-primary">Re-Type Password</label>
			    		    <input class="form-control" name="pass2"  id="pass2" type="password" required placeholder="Re-Type Password">
			    		</div>
			    		<div class="form-group">
							<label for="pass" class="text-primary">Contact</label>
			    			<input class="form-control" id="contact" name="contact" type="text" required placeholder="Contact">
			    		</div>	
						
			    		<button class="btn btn-primary pull-right" name="submit" type="submit"><i class="fa fa-sign-in"></i> Submit</button>
					
			      	</form>
				</div>
		</div>		
	</body>
	<?php include "footer.php"; ?>
	<script>
		$(document).ready(function(){
			$("#pass2").blur(function(){
				var pass1=$("#pass1").val();
				var pass2=$("#pass2").val();
				if(pass1==pass2)
				{
				}
				else{
					alert("Re Type Password Mismatch");
					$("#pass2").val("");
				}
			});
		});
	</script>
</html>