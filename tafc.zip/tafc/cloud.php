<html>
	<?php include "head.php"; 
	session_start();
	?>
	<?php include "config.php"; ?>
	<body style="background-image:url(pic/pic01.jpg); background-size:cover;">
		<?php include "top_nav.php"; ?>
		<div class="row">
	
				<div class="col-md-offset-7 col-md-4 " style='margin-top:10px;'>
					<h2 class='head' style="color:yellow;">Cloud- Server Login</h2>
					<?php 
						if(isset($_POST["submit"]))
						{
							$sql="select * from cloud_tab where CNAME='{$_POST["cname"]}' and CPASS='{$_POST["cpass"]}'";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								$row=$res->fetch_assoc();
								header("location:chome.php");
								$_SESSION["ID"]=$row["CID"];
								$_SESSION["CNAME"]=$row["CNAME"];
								
							}
							else
							{
								echo "<div class='alert alert-danger'>Username and Password Mismatch</div>";
							}
						}
					?>
					<hr>
					 
						<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
			    	  	<div class="form-group">
							 <label for="user_name" class="text-primary">User Name</label>
			    		    <input class="form-control" name="cname"  id="user" type="text" required>
			    		</div>
			    		<div class="form-group">
							<label for="pass" class="text-primary">Password</label>
			    			<input class="form-control" id="cpass" name="cpass" type="password" value="" required>
			    		</div>	
			    		<button class="btn btn-primary pull-right" name="submit" type="submit"><i class="fa fa-sign-in"></i> Login Here</button>
			      	</form>
				</div>
		</div>
	
	</body>
	<?php include "footer.php"; ?>
</html>