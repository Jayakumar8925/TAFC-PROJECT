<?php 
	include "config.php";
	$sql="delete from secret_keys where SID='{$_GET["id"]}'";
	if($con->query($sql))
	{
		header("location:secret_key.php?stat=1");
	}
?>