<html>
	<?php 
	
	session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
	if(isset($_SESSION["UID"]))
	{
	}
	else{
		header("location:index.php");
	}
	?>
	<?php include "config.php";
		include "head.php"; 
	?>
	<body style="background-image:url(pic/10.jpg); background-size:cover; color:white;">
		<?php include "top_nav.php"; ?>
		<div class="container" style="margin-top:40px;">
		<div class="row">
				<div class="col-md-3">
					<?php include "user_side_nav.php"; ?>
				</div>
				<div class="col-md-9" >
					
					<h2 style="color:yellow;"><i class='fa fa-download'></i> Download File</h2><hr>
					<br><br>
					<div class='col-md-offset-3 col-md-4'>
							<div class='form-group'>
								<label >File Name</label>
								<input type='text' id='fname' class='form-control' placeholder='File Name'>
							</div>
							<div class='form-group'>
								<label>Secret Key</label>
								<input type='text' id='skey' class='form-control' placeholder='Secret Key'>
							</div>
							<input type='button' class='btn btn-success pull-right btn-sm' id='bt' value='download'> 
					</div>
				</div>	
				
						
				</div>		
		</div>
		<?php include "footer.php"; ?>
	</body>
	<script>
		$(document).ready(function(){
			$("#bt").click(function(){
				var fname=$("#fname").val();
				var skey=$("#skey").val();
				if(fname!=""&&skey!="")
				{
					$.post("fdown.php",{fname:fname,skey:skey},function(data){

						if(data==1)
						{
							window.open("download_file.php?id="+skey,'_self');
						}
						else if(data==2)
						{
							alert("Download Failed !!!  Time Expired...");
						}
						else{
							alert("File Name and key Not Match");
						}
					});
				}
			});
		});
	</script>
</html>
