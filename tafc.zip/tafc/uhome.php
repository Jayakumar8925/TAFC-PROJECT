<html>
	<?php 
	
	session_start();
	include"enc.php";
	$key ="!@#123!@#";
	$crypt = new Encryption($key);
	
	if(isset($_SESSION["UID"]))
	{
	}
	else{
		header("location:index.php");
	}
	?>
	<?php include "config.php";
		include "head.php"; 
	?>
	<body style="background-image:url(pic/10.jpg); background-size:cover; color:white;">
		<?php include "top_nav.php"; ?>
		<div class="container" style="margin-top:40px;">
		<div class="row">
				<div class="col-md-3">
					<?php include "user_side_nav.php"; ?>
				</div>
			
				<div class="col-md-9">
					<h2><i class='fa fa-home'></i> Home</h2><hr>
				<p style="text-indent:100px; line-height:30px; font-weight:bold;">The new paradigm of outsourcing data to the cloud is a double-edged sword. On one side, it frees up data owners from the technical management, and is easier for the data owners to share their data with intended recipients when data are stored in the cloud. On the other side, it brings about new challenges about privacy and security protection. To protect data confidentiality against the honest-but-curious cloud service provider, numerous works have been proposed to support fine-grained data access control. However, till now, no efficient schemes can provide the scenario of fine-grained access control together with the capacity of time-sensitive data publishing.</p>
				<p style="text-indent:100px; line-height:30px; font-weight:bold;"> In this paper, by embedding the mechanism of timed-release encryption into CPABE (Ciphertext Policy Attribute-Based Encryption), we propose a new time and attribute factors combined access control on time-sensitive data for public cloud storage (named TAFC). Extensive security and performance analysis shows that our proposed scheme is highly efficient and satisfies the security requirements for time-sensitive data storage in public cloud.</p>
				</div>		
		</div>
		<?php include "footer.php"; ?>
	</body>
	<script>
		$(document).ready(function(){
			$(".dates").datepicker({
				dateFormat:"yy-mm-dd"
			});
		});
	</script>
</html>