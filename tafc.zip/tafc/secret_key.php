<html>
	<?php 
	
	session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
	if(isset($_SESSION["UID"]))
	{
	}
	else{
		header("location:index.php");
	}
	?>
	<?php include "config.php";
		include "head.php"; 
	?>
<body style="background-image:url(pic/10.jpg); background-size:cover; color:white;">

		<?php include "top_nav.php"; ?>
		<div class="container" style="margin-top:40px;">
		<div class="row">
				<div class="col-md-3">
					<?php include "user_side_nav.php"; ?>
				</div>
				<div class="col-md-9" >
					
					<h2 style="color:yellow;"><i class='fa fa-key'></i> Secret Keys</h2><hr>
					<div class='col-md-12'>
					<?php 
						if(isset($_GET["stat"]))
						{
							echo "<div class='alert alert-success'>Deleted Successfully</div>";
						}
					?>
					<br>
					
						<?php 
							$sql="Select upload_file.*, upload_file.ODATE, upload_file.CDATE,
  upload_file.UDATE, secret_keys.*, secret_keys.LOGS, secret_keys.UID
From secret_keys Inner Join
  upload_file On secret_keys.FID = upload_file.FID
Where secret_keys.UID  = {$_SESSION["UID"]}";
							$res=$con->query($sql);
							if($con->query($sql))
							{
							?>
								<table class='table table-bordered'>
									<tr>
										<th>S.No</th>
										<th>File Name</th>
										<th>Secret Key</th>
										<th>Key Send</th>
										<th>Update Date</th>
										<th>Open Date</th>
										<th>Close Date</th>
											<th>Open Time</th>
										<th>Close Time</th>
										<th>Delete</th>
									</tr>
							<?php
								$i=0;
								while ($row=$res->fetch_assoc())
								{$i++;
									?>
										<tr>
											<td><?php echo $i;?></td>
											<td><?php echo $crypt->decrypt($row["FILE"]);?></td>
											<td><?php echo $row["FKEY"];?></td>
											<td><?php echo $row["LOGS"];?></td>
											<td><?php echo $row["UDATE"];?></td>
											<td><?php echo $row["ODATE"];?></td>
											<td><?php echo $row["CDATE"];?></td>
											<td><?php echo $row["OTIME"];?></td>
											<td><?php echo $row["CTIME"];?></td>
											<td><a href='del_sec_key.php?id=<?php echo $row["SID"]; ?>' class='btn btn-danger btn-sm'>Delete</a></td>
										</tr>
									<?php
								}
							}
							
						?>
					</table>
					</div>
				</div>	
				
				<div class="col-md-9" id='out' style="background:#000080;" >	
				
				</div>				
				</div>		
		</div>
		<?php include "footer.php"; ?>
	</body>
	<script>
		$(document).ready(function(){
			$("#bt").click(function(){
				var txt=$("#stxt").val();
				if(txt!="")
				{
					$.post("search.php",{txt:txt},function(data){
						$("#out").html(data);
					});
				}
			});
		});
	</script>
</html>
