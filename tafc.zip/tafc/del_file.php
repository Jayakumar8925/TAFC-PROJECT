<?php
	include "config.php";
	include"enc.php";
	$key ="!@#123!@#";
	$crypt = new Encryption($key);
	$sql="select FILE from upload_file where FID='{$_GET["id"]}'";
	$res=$con->query($sql);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		unlink("files/".$crypt->decrypt($row["FILE"]));
		$sql="delete from upload_file where FID='{$_GET["id"]}'";
		if($con->query($sql))
		{
		header("location:dhome.php?stat=1");	
		}
	}
?>