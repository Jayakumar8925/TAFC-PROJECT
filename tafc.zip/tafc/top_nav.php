<style>
	p{
		color:white;
		margin-top:10px;
		margin-left:10px;
	}
	a:hover{
		text-decoration:none;
	}
</style>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation" >
		
		  <div class="navbar-header"><a href='index.php'><p>TAFC Access Control<p></a>
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>	
						<span class="icon-bar"></span>
			  </button>					
		  </div>
		 
		  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
				<?php if(!isset($_SESSION["ID"])&&!isset($_SESSION["CID"])&&!isset($_SESSION["UID"])){?>
					 <li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
					 <li><a href="cloud.php"><i class="fa fa-home"></i> Cloud</a></li>
					 <li><a href="central.php"><i class="fa fa-home"></i> Central Authority</a></li>
					 <li><a href="owner.php"><i class="fa fa-home"></i> Data Owner</a></li>
					 <li><a href="user.php"><i class="fa fa-home"></i> User&nbsp&nbsp&nbsp;</a></li>
				<?php }else{?>
				<li><a href="logout.php"><i class="fa fa-home"></i> Logout&nbsp&nbsp&nbsp;</a></li>
				<?php } ?>
				</ul>
		  </div>
</nav>