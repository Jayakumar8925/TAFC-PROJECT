<style>
	.sid ul{	
		
	}
	.sid ul li{
	
	}
	.sid ul li a{

		color:white!important;
		font-size:18px;
		font-family:vijaya;
		border:solid 2px white;
	}
	.sid ul li a:hover
	{
		color:black!important;
	}
	hr{
		padding:0px!important;
		margin:0px!important;
	}
</style>
<div class="sid">
<ul class="nav nav-pills nav-stacked" >
	<li><a href="uhome.php"> <i class="fa fa-Home"></i> Home</a><hr></li>
	<li><a href="search_file.php"> <i class="fa fa-search"></i> Search File</a><hr></li>
	<li><a href="secret_key.php"> <i class="fa fa-key"></i> SecretKey</a><hr></li>
	<li><a href="download.php"> <i class="fa fa-download"></i> Download</a><hr></li>
	
	<li><a href="logout.php"> <i class="fa fa-arrow-left"></i> Logout</a></li>

	
</ul>
</div>
