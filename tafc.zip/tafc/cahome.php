	<html>
		<?php 
		
		session_start();
		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
		
		if(isset($_SESSION["CID"]))
		{
		}
		else{
			header("location:index.php");
		}
		?>
		<?php include "config.php";
			include "head.php"; 
		?>
		<body style="background-image:url(pic/04.jpg); color:white; background-size:cover;">
			<?php include "top_nav.php"; ?>
			<div class="container" style="margin-top:40px;">
			<div class="row">
					<div class="col-md-3">
						<?php include "ca_side_nav.php"; ?>
					</div>
				
					<div class="col-md-9">
						<h2><i class='fa fa-user'></i> Users</h2><hr><br>
						<?php
							$sql="select * from user_tab";
							$res=$con->query($sql);
							if($res->num_rows>0)
							{
								?>
									<table class='table table-bordered'>
										<tr>
											<th>S.No</th>
											<th>Users Name</th>
											<th>Email Id</th>
											<th>Password</th>
											<th>Contact</th>
										</tr>
								<?php
								$i=0;
								while($row=$res->fetch_assoc())
								{$i++;
								?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $row["UNAME"]; ?></td>
										<td><?php echo $row["EMAIL"]; ?></td>
										<td><?php echo $row["UPASS"]; ?></td>
										<td><?php echo $row["CONTACT"]; ?></td>
									</tr>
								<?php
									
								}
							}
						?>
					</table>
					</div>		
			</div>
			<?php include "footer.php"; ?>
		</body>
		<script>
			$(document).ready(function(){
				$(".dates").datepicker({
					dateFormat:"yy-mm-dd"
				});
			});
		</script>
	</html>