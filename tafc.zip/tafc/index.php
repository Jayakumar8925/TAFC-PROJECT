<html>
	<?php include "head.php"; ?>
	<?php include "config.php"; ?>
	<body style="background-image:url(pic/c.gif); background-size:cover;">
		<?php include "top_nav.php"; ?>
		<div class='row'>
			<div class='col-md-12'>
				<div class="container" >
		 <h1 style="font-family:Calibri; font-size:60px; color:yellow;" align="center" ><b>TAFC ACCESS CONTROL</b></h1><br>
				 <h4 style="font-family:Comic Sans MS; text-transform:capitalize;  color:white; word-spacing:10px;  font-size:25px; text-indent:55px; ">
		Cloud storage service has significant advantages on both
		convenient data sharing and cost reduction. However, this new
		paradigm of data storage brings about new challenges about
		data confidentiality protection. Data are no longer in data
		owner’s trusted domain, and he/she cannot trust the cloud
		server to conduct secure data access control. Therefore, the
		secure access control problem has become a challenging issue
		in cloud storage
					</h4>
			<h4 style="font-family:Comic Sans MS; text-transform:capitalize; color:white; word-spacing:10px;  font-size:25px; text-indent:55px; ">
					There have been numerous works on privacy prserving data sharing in cloud based on various cryptographic
		primitives, in which the schemes based on CP-ABE
		attract extensive attentions, since they can guarantee data
		owner fine-grained and flexible access control of his/her own
		data. However, these schemes determine user’s access privilege
		only based on his/her inherent attributes without any other
		critical aspects, such as the time factor. In reality, the time
		factor usually plays an important role in dealing with time sensitive data (e.g. to publish a latest electronic magazine,
		to expose a company’s future business plan). When uploading
		time-sensitive data to the cloud, the data owner may want
		different users to access the content after different time.
		However, to the best of our knowledge, existing CP-ABE based
		schemes cannot meet such requirement.
					</h4>
			</div>
			</div>
		</div>
		
	</body>
	<?php include "footer.php"; ?>
</html>