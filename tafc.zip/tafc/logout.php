<?php 
session_start();
		unset($_SESSION["ID"]);
		unset($_SESSION["CID"]);
		unset($_SESSION["UID"]);
		session_destroy();
		echo "<script>window.open('index.php','_self')</script>";
?>