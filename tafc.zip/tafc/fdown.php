<?php

		include"enc.php";
		$key ="!@#123!@#";
		$crypt = new Encryption($key);
		include "config.php";
		$sql="select * from upload_file where FKEY='{$_POST["skey"]}' ";
		$res=$con->query($sql);
		if($res->num_rows>0)
		{
			$row=$res->fetch_assoc();
			$fname=$crypt->decrypt($row["FILE"]);
			if($fname==$_POST["fname"])
			{	$date=date("Y-m-d");
				if($row["ODATE"]<=$date&&$date<=$row["CDATE"])
				{
					echo "1";
				}
				else
				{
					echo "2";
				}
			}
			else
			{
				echo "0";
			}
		}
		else{
			echo "0";
	 }
		
?>