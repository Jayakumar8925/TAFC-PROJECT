<style>

	.sid ul{	
	
	}
	.sid ul li{
	
	}
	.sid ul li a{


		font-size:18px;
		font-family:vijaya;
		border:solid 2px white;
		background:#002740;
		color:white!important;
	}
	.sid ul li a:hover
	{
		color:black!important;
	}
	hr{
		padding:0px!important;
		margin:0px!important;
	}
</style>
<div class="sid">
<ul class="nav nav-pills nav-stacked" >
	<li><a href="cahome.php"> <i class="fa fa-user"></i> Users</a></li>
	<li><a href="ca_files.php"> <i class="fa fa-file"></i> Files</a></li>
	<li><a href="view_sk.php"> <i class="fa fa-key"></i> SK Requests</a></li>
	<li><a href="cl_attackers.php"> <i class="fa fa-download"></i> View Attackers</a></li>
	
	<li><a href="logout.php"> <i class="fa fa-arrow-left"></i> Logout</a></li>

	
</ul>
</div>
