<?php 
	include "config.php";
	 $sql="insert into secret_keys(FID,FKEY,UID,LOGS)values({$_POST["fid"]},'{$_POST["ky"]}',{$_POST["uid"]},NOW())";
	if($con->query($sql))
	{
		$sql="update request_tab set STATUS=1 where RID={$_POST["rid"]}";
		$con->query($sql);
	}
	
?>