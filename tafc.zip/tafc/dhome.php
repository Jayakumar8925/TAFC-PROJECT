<html>
	<?php 
	
	session_start();
	include"enc.php";
	$key ="!@#123!@#";
	$crypt = new Encryption($key);
	if(isset($_SESSION["ID"]))
	{
	}
	else{
		header("location:index.php");
	}
	?>
	<?php include "config.php";
		include "head.php"; 
	?>
	<body style="background-image:url(pic/08.jpg);  background-size:cover; color:white; ">
		<?php include "top_nav.php"; ?>
		<div class="container" style="margin-top:40px;">
		<div class="row">
				
				
				<div class="col-md-offset-3 col-md-6">
				<h2 style="color:yellow"><i class='fa fa-upload' style="color:yellow"></i> Upload Data</h2><hr>
				<?php 
				
function safe_valu($vkeyname)
	{
		if (isset($_GET[$vkeyname])) { return $_GET[$vkeyname]; }
		if (isset($_POST[$vkeyname])) { return $_POST[$vkeyname]; }
		return "";
	}
	function rand_numb()
	{
		$o = "";
		for ($x = 0; $x < 6; $x += 1) { $o .= rand(0, 9); }
		return $o;
	}
	function remo_file($pathname)
	{
		if (!is_file($pathname)) { return 0; }
		$fmodtime = filectime($pathname);
		$lastfmod = intval((time() - $fmodtime) / (60 * 60));
		if ($lastfmod >= 48) { unlink($pathname); return 1; }
		return 0;
	}
	date_default_timezone_set("America/Toronto");
	srand(microtime() * 1000000);
	$WEB_EOL = "<br/>";
	$writedir = "files/";
	$scptmode = safe_valu("mode");
	$pinncode = preg_replace("/[^0-9]/i", "", safe_valu("pinc"));
	$password = safe_valu("pass");
	$aeskhash = hash("SHA256", $password, true);
	if ($scptmode == "e")
	{
		$aesinitv = openssl_random_pseudo_bytes(16);
		if (($_FILES["file"]["error"] < 1) && ($_FILES["file"]["size"] < 4096000))
		{
			while (1)
			{
				$pinncode = rand_numb();
				$filename = ($writedir."/".$pinncode);
				if (!file_exists($filename)) { break; }
				if (remo_file($filename) == 1) { break; }
			}
			$fsrcobjc = fopen($_FILES["file"]["tmp_name"], "rb");
			$fdstobjc = fopen($filename, "wb");
			if (($fsrcobjc !== false) && ($fdstobjc !== false))
			{
				fwrite($fdstobjc, "".$_FILES["file"]["name"].""); # filename as string (unknown length)
				fwrite($fdstobjc, "\1"); # non-printable separator (1 byte)
				fwrite($fdstobjc, "".$_FILES["file"]["size"].""); # filesize in bytes (unknown length)
				fwrite($fdstobjc, "\1"); # non-printable separator (1 byte)
				$emessage = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $aeskhash, "magicstring", MCRYPT_MODE_CBC, $aesinitv);
				fwrite($fdstobjc, $emessage); # encrypted magic string (16 bytes)
				fwrite($fdstobjc, $aesinitv); # initialization vector (16 bytes)
				while (!feof($fsrcobjc))
				{
					$fsrcdata = fread($fsrcobjc, 16);
					$emessage = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $aeskhash, $fsrcdata, MCRYPT_MODE_CBC, $aesinitv);
					fwrite($fdstobjc, $emessage);
					$aesinitv = $emessage;
				}
				fclose($fdstobjc);
				fclose($fsrcobjc);
				chmod($filename, 0770);
			}
		}
	}
	if ($scptmode == "d")
	{
		$filelist = scandir($writedir);
		foreach ($filelist as $fileitem)
		{
			$itemname = ($writedir."/".$fileitem);
			if (remo_file($itemname) == 1) { continue; }
			if ($fileitem != $pinncode) { continue; }
			$fsrcobjc = fopen($itemname, "rb");
			if ($fsrcobjc !== false)
			{
				$filename = ""; $filechar = "";
				while ($filechar != "\1") { $filename .= $filechar; $filechar = fread($fsrcobjc, 1); }
				$filesize = ""; $filechar = "";
				while ($filechar != "\1") { $filesize .= $filechar; $filechar = fread($fsrcobjc, 1); }
				$filesize = intval($filesize);
				$magicode = fread($fsrcobjc, 16);
				$aesinitv = fread($fsrcobjc, 16);
				$dmessage = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $aeskhash, $magicode, MCRYPT_MODE_CBC, $aesinitv);
				if (rtrim($dmessage) == "magicstring")
				{
					header('Content-Type: application/octet-stream');
					header('Content-Disposition: attachment; filename="'.$filename.'"');
					header('Content-Length: '.$filesize);
					$tempinit = $aesinitv;
					while ($filesize > 0)
					{
						$aesinitv = $tempinit;
						$fsrcdata = fread($fsrcobjc, 16);
						$tempinit = $fsrcdata;
						$dmessage = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $aeskhash, $fsrcdata, MCRYPT_MODE_CBC, $aesinitv);
						$templeng = 16; if ($filesize < 16) { $templeng = $filesize; }
						print(substr($dmessage, 0, $templeng));
						$filesize -= 16;
					}
					fclose($fsrcobjc);
					exit(0);
				}
				fclose($fsrcobjc);
			}
		}
	}
?>

		
				<?php 
					if(isset($_POST["submit"]))
					{	
							
							
							
								$file= $crypt->encrypt($_FILES["file"]["name"]);
								$fname= $crypt->encrypt($_POST["fname"]);
								$fatt= $crypt->encrypt($_POST["fatt"]);
								
								$sql="insert into upload_file (DID,FNAME,FATT,FKEY,ODATE,CDATE,OTIME,CTIME,UDATE,FILE)values({$_SESSION["ID"]},'{$fname}','{$fatt}','{$pinncode}','{$_POST["odate"]}','{$_POST["cdate"]}','{$_POST["otime"]}','{$_POST["ctime"]}',NOW(),'{$file}')";
								if($con->query($sql))
								{
									echo "<div class='alert alert-success'>Upload Success</div>";
								}
							
					}
				
				?>
				
					<form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post" enctype="multipart/form-data">
					<input type="hidden" name="mode" value="e" />
					<?php
						if(isset($_GET["stat"]))
						{
							echo"<div class='alert alert-success'>Deleted Successfully</div>";
						}
					?>
						<div class="form-group">
						<label>Select File</label>
						<input type="file" name="file" id="file" class='form-control' required>

						</div>
						<div class="form-group">
							<label>File Name</label>
							<input type='text' name='fname' class='form-control' required>
						</div>
						<div class="form-group">
							<label>File Attribute Name</label>
							<input type='text' name='fatt' class='form-control' required>
						</div>
						<div class="form-group">
							<label>Open Date</label>
							<input type='text' name='odate' class='form-control dates' required>
						</div>
						<div class="form-group">
							<label>End Date</label>
							<input type='text' name='cdate' class='form-control dates' required>
						</div>
						<div class="form-group">
							<label>Open Time</label>
							<input type='number' name='otime' class='form-control' min="0" max="24" required>
						</div>
						<div class="form-group">
							<label>End Time</label>
							<input type='number' name='ctime' class='form-control' min="0" max="24" required>
						</div>
						<input type="submit" name="submit" value="Next" class='btn btn-primary pull-right  btn-sm' >
					</form>
					
				</div>
				
				<div class="col-md-12">
				<br>

					<?php
						$sql="select * from upload_file where DID='{$_SESSION["ID"]}'";
						$res=$con->query($sql);
						if($res->num_rows>0)
						{
						?>
							<table class='table table-bordered'>
								<tr>
									<th>S.No</th>
									<th>File</th>
									<th>File Name</th>
									<th>Attribute</th>
									<th>Key</th>
									<th>Open Date</th>
									<th>End Date</th>
									<th>Open Time</th>
									<th>End Time</th>
									<th>Upload Date</th>
									
									<td>Delete</td>
								</tr>
						<?php
							$i=0;
							while($row=$res->fetch_assoc())
							{$i++;
								?>
									<tr>
										<td><?php echo $i; ?></td>
										<td><?php echo $crypt->decrypt($row["FILE"]);?></td>
										<td><?php echo$crypt->decrypt($row["FNAME"]); ?></td>
										<td><?php echo $crypt->decrypt($row["FATT"]);?></td>
										<td><?php echo $row["FKEY"];?></td>
										<td><?php echo $row["ODATE"];?></td>
										<td><?php echo $row["CDATE"]?></td>
										
										<td><?php echo $row["OTIME"]?></td>
										<td><?php echo $row["CTIME"]?></td>
										<td><?php echo $row["UDATE"]?></td>
										<td><a class='btn btn-danger btn-sm' href="del_file.php?id=<?php echo $row["FID"];?>">Delete</a></td>
										
									</tr>
								<?php								
							}
						}
					?>
					</table>
				</div>
		</div>		
		</div>
		<?php include "footer.php"; ?>
	</body>
	<script>
		$(document).ready(function(){
			$(".dates").datepicker({
				dateFormat:"yy-mm-dd"
			});
		});
	</script>
</html>