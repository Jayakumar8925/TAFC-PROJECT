<style>
	.sid ul{	
		
	}
	.sid ul li{
	
	}
	.sid ul li a{

		color:white!important;
		font-size:18px;
		font-family:vijaya;
		border:solid 2px white;
		
	
	}
	.sid ul li a:hover
	{
		color:black!important;
		
	}
	hr{
		padding:0px!important;
		margin:0px!important;
	}
</style>
<div class="sid">
<ul class="nav nav-pills nav-stacked" >
	<li><a href="chome.php"> <i class="fa fa-users"></i> Data Owners</a></li>
	<li><a href="users.php"> <i class="fa fa-user"></i> Users</a></li>
	<li><a href="view_file.php"> <i class="fa fa-file"></i> Files</a></li>
	<li><a href="logout.php"> <i class="fa fa-arrow-left"></i> Logout</a></li>

	
</ul>
</div>
