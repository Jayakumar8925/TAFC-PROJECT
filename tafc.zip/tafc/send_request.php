<?php 
	include "config.php";
	$sql="insert into request_tab(FID,UID,LOGS)values({$_POST["fid"]},{$_POST["uid"]},NOW())";
	if($con->query($sql))
	{
		echo "Request Send Successfully";
	}
?>